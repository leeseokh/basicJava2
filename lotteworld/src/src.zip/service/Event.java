package service;

public class Event {

}
