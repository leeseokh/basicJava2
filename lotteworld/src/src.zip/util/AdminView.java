package util;

public class AdminView {
	
	public static final int HOME = 0;
	public static final int LOGIN = 1;
	public static final int NOTICE = 2;
	public static final int FAQ = 3;
	public static final int EVENT = 4;
	public static final int GUIDE_LIST = 5;
	
}
